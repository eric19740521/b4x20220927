package b4a.example.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_mainpage{

public static void LS_320x480_1(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 4;BA.debugLine="Button1.Top = Panel2.Height*(1/2)-Button1.Height*(1/2)"[MainPage/320x480,scale=1]
views.get("button1").vw.setTop((int)((views.get("panel2").vw.getHeight())*(1d/2d)-(views.get("button1").vw.getHeight())*(1d/2d)));
//BA.debugLineNum = 6;BA.debugLine="Button3.Top = Panel2.Height*(1/2)-Button1.Height*(1/2)"[MainPage/320x480,scale=1]
views.get("button3").vw.setTop((int)((views.get("panel2").vw.getHeight())*(1d/2d)-(views.get("button1").vw.getHeight())*(1d/2d)));
//BA.debugLineNum = 9;BA.debugLine="Button1.Width = (Panel2.Width-(3*5))/2"[MainPage/320x480,scale=1]
views.get("button1").vw.setWidth((int)(((views.get("panel2").vw.getWidth())-(3d*5d))/2d));
//BA.debugLineNum = 11;BA.debugLine="Button3.Width = Button1.Width"[MainPage/320x480,scale=1]
views.get("button3").vw.setWidth((int)((views.get("button1").vw.getWidth())));
//BA.debugLineNum = 13;BA.debugLine="Button1.Left = 5"[MainPage/320x480,scale=1]
views.get("button1").vw.setLeft((int)(5d));
//BA.debugLineNum = 15;BA.debugLine="Button3.Left = Button1.Left+Button1.Width+5"[MainPage/320x480,scale=1]
views.get("button3").vw.setLeft((int)((views.get("button1").vw.getLeft())+(views.get("button1").vw.getWidth())+5d));

}
public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);

}
}