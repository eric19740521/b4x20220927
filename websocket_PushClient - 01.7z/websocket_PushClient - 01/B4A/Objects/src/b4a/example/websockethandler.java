package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class websockethandler extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.websockethandler");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.websockethandler.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.WebSocketWrapper _ws = null;
public Object _callback = null;
public String _eventname = "";
public b4a.example.dateutils _dateutils = null;
public b4a.example.main _main = null;
public b4a.example.starter _starter = null;
public b4a.example.b4xpages _b4xpages = null;
public b4a.example.b4xcollections _b4xcollections = null;
public b4a.example.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 4;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 5;BA.debugLine="Public ws As WebSocket";
_ws = new anywheresoftware.b4a.objects.WebSocketWrapper();
 //BA.debugLineNum = 6;BA.debugLine="Private CallBack As Object";
_callback = new Object();
 //BA.debugLineNum = 7;BA.debugLine="Private EventName As String";
_eventname = "";
 //BA.debugLineNum = 8;BA.debugLine="End Sub";
return "";
}
public String  _close() throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Public Sub Close";
 //BA.debugLineNum = 23;BA.debugLine="Log(\"WebSocketHandler Close==>\")";
__c.LogImpl("12424833","WebSocketHandler Close==>",0);
 //BA.debugLineNum = 25;BA.debugLine="If ws.Connected Then ws.Close";
if (_ws.getConnected()) { 
_ws.Close();};
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public String  _connect(String _url) throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Public Sub Connect(Url As String)";
 //BA.debugLineNum = 17;BA.debugLine="Log(\"WebSocketHandler Connect==>\")";
__c.LogImpl("12359297","WebSocketHandler Connect==>",0);
 //BA.debugLineNum = 19;BA.debugLine="ws.Connect(Url)";
_ws.Connect(_url);
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _vcallback,String _veventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 10;BA.debugLine="Public Sub Initialize (vCallback As Object, vEvent";
 //BA.debugLineNum = 11;BA.debugLine="CallBack = vCallback";
_callback = _vcallback;
 //BA.debugLineNum = 12;BA.debugLine="EventName = vEventName";
_eventname = _veventname;
 //BA.debugLineNum = 13;BA.debugLine="ws.Initialize(\"ws\")";
_ws.Initialize(ba,"ws");
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public String  _sendeventbinarytoserver(String _event,anywheresoftware.b4a.objects.collections.Map _data) throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Public Sub SendEventBinaryToServer(Event As String";
 //BA.debugLineNum = 77;BA.debugLine="Log(\"WebSocketHandler SendEventBinaryToServer==>\"";
__c.LogImpl("12621441","WebSocketHandler SendEventBinaryToServer==>",0);
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return "";
}
public String  _sendeventtoserver(String _event,anywheresoftware.b4a.objects.collections.Map _data) throws Exception{
anywheresoftware.b4a.objects.collections.Map _m = null;
anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator _jg = null;
 //BA.debugLineNum = 31;BA.debugLine="Public Sub SendEventToServer(Event As String, Data";
 //BA.debugLineNum = 32;BA.debugLine="Log(\"WebSocketHandler SendEventToServer==>\")";
__c.LogImpl("12490369","WebSocketHandler SendEventToServer==>",0);
 //BA.debugLineNum = 34;BA.debugLine="Try";
try { //BA.debugLineNum = 35;BA.debugLine="Dim m As Map";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 36;BA.debugLine="m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 37;BA.debugLine="m.Put(\"type\", \"event\")";
_m.Put((Object)("type"),(Object)("event"));
 //BA.debugLineNum = 38;BA.debugLine="m.Put(\"event\", Event)";
_m.Put((Object)("event"),(Object)(_event));
 //BA.debugLineNum = 39;BA.debugLine="m.Put(\"params\", Data)";
_m.Put((Object)("params"),(Object)(_data.getObject()));
 //BA.debugLineNum = 40;BA.debugLine="Dim jg As JSONGenerator";
_jg = new anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 41;BA.debugLine="jg.Initialize(m)";
_jg.Initialize(_m);
 //BA.debugLineNum = 42;BA.debugLine="ws.SendText(jg.ToString)";
_ws.SendText(_jg.ToString());
 //BA.debugLineNum = 44;BA.debugLine="Log(\"jg.ToString= \"&jg.ToString)";
__c.LogImpl("12490381","jg.ToString= "+_jg.ToString(),0);
 } 
       catch (Exception e13) {
			ba.setLastException(e13); //BA.debugLineNum = 46;BA.debugLine="Log(\"SendEventToServer Err: \"&LastException)";
__c.LogImpl("12490383","SendEventToServer Err: "+BA.ObjectToString(__c.LastException(getActivityBA())),0);
 };
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public String  _ws_binarymessage(byte[] _data) throws Exception{
 //BA.debugLineNum = 98;BA.debugLine="Sub ws_BinaryMessage (Data() As Byte)";
 //BA.debugLineNum = 99;BA.debugLine="Log(\"WebSocketHandler ws_BinaryMessage==>\")";
__c.LogImpl("12686977","WebSocketHandler ws_BinaryMessage==>",0);
 //BA.debugLineNum = 101;BA.debugLine="Log(\"Binary message received.\")";
__c.LogImpl("12686979","Binary message received.",0);
 //BA.debugLineNum = 103;BA.debugLine="End Sub";
return "";
}
public String  _ws_closed(String _reason) throws Exception{
 //BA.debugLineNum = 113;BA.debugLine="Private Sub ws_Closed (Reason As String)";
 //BA.debugLineNum = 114;BA.debugLine="Log(\"WebSocketHandler ws_Closed==>\")";
__c.LogImpl("12818049","WebSocketHandler ws_Closed==>",0);
 //BA.debugLineNum = 116;BA.debugLine="CallSub2(CallBack, EventName & \"_Closed\", Reason)";
__c.CallSubNew2(ba,_callback,_eventname+"_Closed",(Object)(_reason));
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public String  _ws_connected() throws Exception{
 //BA.debugLineNum = 107;BA.debugLine="Private Sub ws_Connected";
 //BA.debugLineNum = 108;BA.debugLine="Log(\"WebSocketHandler ws_Connected==>\")";
__c.LogImpl("12752513","WebSocketHandler ws_Connected==>",0);
 //BA.debugLineNum = 110;BA.debugLine="CallSub(CallBack,  EventName & \"_Connected\")";
__c.CallSubNew(ba,_callback,_eventname+"_Connected");
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return "";
}
public String  _ws_textmessage(String _msg) throws Exception{
anywheresoftware.b4a.objects.collections.JSONParser _jp = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
String _etype = "";
anywheresoftware.b4a.objects.collections.List _params = null;
String _event = "";
 //BA.debugLineNum = 55;BA.debugLine="Private Sub ws_TextMessage(msg As String)";
 //BA.debugLineNum = 56;BA.debugLine="Log(\"WebSocketHandler ws_TextMessage==>\")";
__c.LogImpl("12555905","WebSocketHandler ws_TextMessage==>",0);
 //BA.debugLineNum = 58;BA.debugLine="Try";
try { //BA.debugLineNum = 59;BA.debugLine="Log(\"msg= \"&msg)";
__c.LogImpl("12555908","msg= "+_msg,0);
 //BA.debugLineNum = 61;BA.debugLine="Dim jp As JSONParser";
_jp = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 62;BA.debugLine="jp.Initialize(msg)";
_jp.Initialize(_msg);
 //BA.debugLineNum = 63;BA.debugLine="Dim m As Map = jp.NextObject";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = _jp.NextObject();
 //BA.debugLineNum = 64;BA.debugLine="Dim etype As String = m.get(\"etype\")";
_etype = BA.ObjectToString(_m.Get((Object)("etype")));
 //BA.debugLineNum = 65;BA.debugLine="Dim params As List = m.get(\"value\")";
_params = new anywheresoftware.b4a.objects.collections.List();
_params = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_m.Get((Object)("value"))));
 //BA.debugLineNum = 66;BA.debugLine="Dim event As String = m.get(\"prop\")";
_event = BA.ObjectToString(_m.Get((Object)("prop")));
 //BA.debugLineNum = 67;BA.debugLine="If etype = \"runFunction\" Then";
if ((_etype).equals("runFunction")) { 
 //BA.debugLineNum = 68;BA.debugLine="CallSub2(CallBack, EventName & \"_\" & event, par";
__c.CallSubNew2(ba,_callback,_eventname+"_"+_event,(Object)(_params));
 };
 } 
       catch (Exception e14) {
			ba.setLastException(e14); //BA.debugLineNum = 71;BA.debugLine="Log(\"TextMessage Error: \" & LastException)";
__c.LogImpl("12555920","TextMessage Error: "+BA.ObjectToString(__c.LastException(getActivityBA())),0);
 };
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
