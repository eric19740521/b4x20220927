package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class b4xmainpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.b4xmainpage");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.b4xmainpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.websockethandler _wsh = null;
public anywheresoftware.b4a.randomaccessfile.B4XSerializator _mb4xserializator = null;
public anywheresoftware.b4a.objects.StringUtils _mstringutils = null;
public double _app_version = 0;
public String _serverlink = "";
public String _serverlink1 = "";
public String _serverlink2 = "";
public b4a.example.b1page _page1 = null;
public boolean _is_b1pagecreate = false;
public boolean _is_page1 = false;
public anywheresoftware.b4a.objects.Timer _reconnecttimer = null;
public anywheresoftware.b4a.objects.Timer _pingtimer = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtdevice_id = null;
public b4a.example.b4xfloattextfield _txtuser_id = null;
public b4a.example.b4xfloattextfield _txtuser_password = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _button3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _checkbox1 = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.main _main = null;
public b4a.example.starter _starter = null;
public b4a.example.b4xpages _b4xpages = null;
public b4a.example.b4xcollections _b4xcollections = null;
public b4a.example.xuiviewsutils _xuiviewsutils = null;
public String  _activityresume() throws Exception{
anywheresoftware.b4a.objects.IntentWrapper _in = null;
 //BA.debugLineNum = 201;BA.debugLine="Public Sub ActivityResume";
 //BA.debugLineNum = 202;BA.debugLine="Log(\"B4XMainPage ActivityResume==>\")";
__c.LogImpl("11048577","B4XMainPage ActivityResume==>",0);
 //BA.debugLineNum = 207;BA.debugLine="Log(\"serverLink= \"&serverLink)";
__c.LogImpl("11048582","serverLink= "+_serverlink,0);
 //BA.debugLineNum = 209;BA.debugLine="Try";
try { //BA.debugLineNum = 211;BA.debugLine="If Is_Page1 Then";
if (_is_page1) { 
 //BA.debugLineNum = 212;BA.debugLine="B4XPages.ShowPageAndRemovePreviousPages(\"page1\"";
_b4xpages._showpageandremovepreviouspages /*String*/ (ba,"page1");
 }else {
 //BA.debugLineNum = 214;BA.debugLine="B4XPages.ShowPage(\"MainPage\")";
_b4xpages._showpage /*String*/ (ba,"MainPage");
 };
 //BA.debugLineNum = 218;BA.debugLine="Dim in As Intent = B4XPages.GetNativeParent(Me).";
_in = new anywheresoftware.b4a.objects.IntentWrapper();
_in = _b4xpages._getnativeparent /*anywheresoftware.b4a.objects.ActivityWrapper*/ (ba,this).GetStartingIntent();
 //BA.debugLineNum = 219;BA.debugLine="Log(\"B4XPages.GetNativeParent= \"&in)";
__c.LogImpl("11048594","B4XPages.GetNativeParent= "+BA.ObjectToString(_in),0);
 } 
       catch (Exception e12) {
			ba.setLastException(e12); //BA.debugLineNum = 223;BA.debugLine="Log(LastException)";
__c.LogImpl("11048598",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 241;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
anywheresoftware.b4a.objects.collections.Map _m = null;
 //BA.debugLineNum = 66;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 67;BA.debugLine="Log(\"B4XMainPage B4XPage_Created==>\")";
__c.LogImpl("1786433","B4XMainPage B4XPage_Created==>",0);
 //BA.debugLineNum = 69;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 70;BA.debugLine="Root.LoadLayout(\"MainPage\")";
_root.LoadLayout("MainPage",ba);
 //BA.debugLineNum = 73;BA.debugLine="B4XPages.SetTitle(Me, \"Login\")";
_b4xpages._settitle /*String*/ (ba,this,(Object)("Login"));
 //BA.debugLineNum = 75;BA.debugLine="page1.Initialize";
_page1._initialize /*Object*/ (ba);
 //BA.debugLineNum = 76;BA.debugLine="B4XPages.AddPage(\"page1\", page1)";
_b4xpages._addpage /*String*/ (ba,"page1",(Object)(_page1));
 //BA.debugLineNum = 79;BA.debugLine="Try";
try { //BA.debugLineNum = 81;BA.debugLine="Log(\"檔案位置: \"&xui.DefaultFolder)";
__c.LogImpl("1786447","檔案位置: "+_xui.getDefaultFolder(),0);
 //BA.debugLineNum = 82;BA.debugLine="If File.Exists(xui.DefaultFolder,\"config.txt\") =";
if (__c.File.Exists(_xui.getDefaultFolder(),"config.txt")==__c.True) { 
 //BA.debugLineNum = 83;BA.debugLine="Dim m As Map= File.ReadMap(xui.DefaultFolder,\"c";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = __c.File.ReadMap(_xui.getDefaultFolder(),"config.txt");
 //BA.debugLineNum = 85;BA.debugLine="txtDevice_Id.Text = m.Get(\"device_id\")";
_txtdevice_id.setText(BA.ObjectToCharSequence(_m.Get((Object)("device_id"))));
 //BA.debugLineNum = 86;BA.debugLine="txtUser_Id.Text = m.Get(\"user_id\")";
_txtuser_id._settext /*String*/ (BA.ObjectToString(_m.Get((Object)("user_id"))));
 //BA.debugLineNum = 88;BA.debugLine="If m.Get(\"CheckBox1\") = Null Then";
if (_m.Get((Object)("CheckBox1"))== null) { 
 //BA.debugLineNum = 89;BA.debugLine="CheckBox1.Checked = True";
_checkbox1.setChecked(__c.True);
 //BA.debugLineNum = 90;BA.debugLine="serverLink = serverLink2";
_serverlink = _serverlink2;
 }else {
 //BA.debugLineNum = 92;BA.debugLine="CheckBox1.Checked = m.Get(\"CheckBox1\")";
_checkbox1.setChecked(BA.ObjectToBoolean(_m.Get((Object)("CheckBox1"))));
 //BA.debugLineNum = 94;BA.debugLine="If CheckBox1.Checked Then";
if (_checkbox1.getChecked()) { 
 //BA.debugLineNum = 95;BA.debugLine="serverLink = serverLink2";
_serverlink = _serverlink2;
 }else {
 //BA.debugLineNum = 97;BA.debugLine="serverLink = serverLink1";
_serverlink = _serverlink1;
 };
 };
 }else {
 //BA.debugLineNum = 102;BA.debugLine="CheckBox1.Checked = True";
_checkbox1.setChecked(__c.True);
 //BA.debugLineNum = 103;BA.debugLine="serverLink = serverLink2";
_serverlink = _serverlink2;
 };
 //BA.debugLineNum = 105;BA.debugLine="txtUser_Password.Text = \"\"";
_txtuser_password._settext /*String*/ ("");
 } 
       catch (Exception e30) {
			ba.setLastException(e30); //BA.debugLineNum = 116;BA.debugLine="Log(LastException)";
__c.LogImpl("1786482",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 119;BA.debugLine="txtUser_Password.RequestFocusAndShowKeyboard";
_txtuser_password._requestfocusandshowkeyboard /*String*/ ();
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return "";
}
public String  _button1_click() throws Exception{
String _cred = "";
anywheresoftware.b4a.objects.StringUtils _su = null;
String _encoded = "";
 //BA.debugLineNum = 125;BA.debugLine="Private Sub Button1_Click";
 //BA.debugLineNum = 126;BA.debugLine="Log(\"B4XMainPage Button1_Click==>\")";
__c.LogImpl("1851969","B4XMainPage Button1_Click==>",0);
 //BA.debugLineNum = 129;BA.debugLine="If txtUser_Id.Text = \"\" Then";
if ((_txtuser_id._gettext /*String*/ ()).equals("")) { 
 //BA.debugLineNum = 130;BA.debugLine="xui.MsgboxAsync(\"must input user account\",\"提示\")";
_xui.MsgboxAsync(ba,BA.ObjectToCharSequence("must input user account"),BA.ObjectToCharSequence("提示"));
 //BA.debugLineNum = 133;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 146;BA.debugLine="wsh.Initialize(Me, \"wsh\")";
_wsh._initialize /*String*/ (ba,this,"wsh");
 //BA.debugLineNum = 147;BA.debugLine="If wsh.ws.Connected = True Then";
if (_wsh._ws /*anywheresoftware.b4a.objects.WebSocketWrapper*/ .getConnected()==__c.True) { 
 //BA.debugLineNum = 148;BA.debugLine="wsh.Close";
_wsh._close /*String*/ ();
 };
 //BA.debugLineNum = 154;BA.debugLine="Dim cred As String";
_cred = "";
 //BA.debugLineNum = 155;BA.debugLine="cred = $\"${txtUser_Id.text}:${txtUser_Password.te";
_cred = (""+__c.SmartStringFormatter("",(Object)(_txtuser_id._gettext /*String*/ ()))+":"+__c.SmartStringFormatter("",(Object)(_txtuser_password._gettext /*String*/ ()))+"");
 //BA.debugLineNum = 156;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 157;BA.debugLine="Dim encoded As String";
_encoded = "";
 //BA.debugLineNum = 158;BA.debugLine="encoded = su.EncodeBase64(cred.GetBytes(\"UTF8\"))";
_encoded = _su.EncodeBase64(_cred.getBytes("UTF8"));
 //BA.debugLineNum = 160;BA.debugLine="wsh.ws.Headers = CreateMap(\"Authorization\":\"Basic";
_wsh._ws /*anywheresoftware.b4a.objects.WebSocketWrapper*/ .Headers = __c.createMap(new Object[] {(Object)("Authorization"),(Object)("Basic "+_encoded)});
 //BA.debugLineNum = 164;BA.debugLine="wsh.Connect(serverLink)";
_wsh._connect /*String*/ (_serverlink);
 //BA.debugLineNum = 165;BA.debugLine="ProgressDialogShow(\"Connect~~~\"&serverLink)";
__c.ProgressDialogShow(ba,BA.ObjectToCharSequence("Connect~~~"+_serverlink));
 //BA.debugLineNum = 169;BA.debugLine="End Sub";
return "";
}
public String  _button3_click() throws Exception{
 //BA.debugLineNum = 175;BA.debugLine="Private Sub Button3_Click";
 //BA.debugLineNum = 177;BA.debugLine="txtDevice_Id.Text = \"\"";
_txtdevice_id.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 178;BA.debugLine="txtUser_Id.Text = \"\"";
_txtuser_id._settext /*String*/ ("");
 //BA.debugLineNum = 179;BA.debugLine="txtUser_Password.Text = \"\"";
_txtuser_password._settext /*String*/ ("");
 //BA.debugLineNum = 182;BA.debugLine="End Sub";
return "";
}
public String  _checkbox1_checkedchange(boolean _checked) throws Exception{
 //BA.debugLineNum = 185;BA.debugLine="Private Sub CheckBox1_CheckedChange(Checked As Boo";
 //BA.debugLineNum = 186;BA.debugLine="Log(\"CheckBox1_CheckedChange==>\")";
__c.LogImpl("1983041","CheckBox1_CheckedChange==>",0);
 //BA.debugLineNum = 188;BA.debugLine="If Checked Then";
if (_checked) { 
 //BA.debugLineNum = 189;BA.debugLine="serverLink = serverLink2";
_serverlink = _serverlink2;
 }else {
 //BA.debugLineNum = 191;BA.debugLine="serverLink = serverLink1";
_serverlink = _serverlink1;
 };
 //BA.debugLineNum = 193;BA.debugLine="Log(\"serverLink= \"&serverLink)";
__c.LogImpl("1983048","serverLink= "+_serverlink,0);
 //BA.debugLineNum = 198;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private Root As B4XView";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private wsh As WebSocketHandler";
_wsh = new b4a.example.websockethandler();
 //BA.debugLineNum = 14;BA.debugLine="Private mB4XSerializator As B4XSerializator";
_mb4xserializator = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 15;BA.debugLine="Private mStringUtils As StringUtils";
_mstringutils = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 19;BA.debugLine="Private APP_VERSION As Double = 1.0";
_app_version = 1.0;
 //BA.debugLineNum = 20;BA.debugLine="Public serverLink As String = \"\"";
_serverlink = "";
 //BA.debugLineNum = 21;BA.debugLine="Public serverLink1 As String = \"ws://192.168.1.15";
_serverlink1 = "ws://192.168.1.152/push/b4a";
 //BA.debugLineNum = 22;BA.debugLine="Public serverLink2 As String = \"wss://b234.top/pu";
_serverlink2 = "wss://b234.top/push/b4a";
 //BA.debugLineNum = 25;BA.debugLine="Private page1 As B1Page";
_page1 = new b4a.example.b1page();
 //BA.debugLineNum = 26;BA.debugLine="Private Is_B1PageCreate As Boolean = False";
_is_b1pagecreate = __c.False;
 //BA.debugLineNum = 27;BA.debugLine="Private Is_Page1 As Boolean = False";
_is_page1 = __c.False;
 //BA.debugLineNum = 29;BA.debugLine="Dim wsh As WebSocketHandler";
_wsh = new b4a.example.websockethandler();
 //BA.debugLineNum = 30;BA.debugLine="Private ReconnectTimer As Timer";
_reconnecttimer = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 31;BA.debugLine="Private pingTimer As Timer";
_pingtimer = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 35;BA.debugLine="Private txtDevice_Id As B4XView";
_txtdevice_id = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 36;BA.debugLine="Private txtUser_Id As B4XFloatTextField";
_txtuser_id = new b4a.example.b4xfloattextfield();
 //BA.debugLineNum = 37;BA.debugLine="Private txtUser_Password As B4XFloatTextField";
_txtuser_password = new b4a.example.b4xfloattextfield();
 //BA.debugLineNum = 40;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 43;BA.debugLine="Private Button3 As B4XView";
_button3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 47;BA.debugLine="Private CheckBox1 As B4XView";
_checkbox1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 51;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 52;BA.debugLine="Log(\"B4XMainPage Initialize==>\")";
__c.LogImpl("1720897","B4XMainPage Initialize==>",0);
 //BA.debugLineNum = 59;BA.debugLine="ReconnectTimer.Enabled = False";
_reconnecttimer.setEnabled(__c.False);
 //BA.debugLineNum = 60;BA.debugLine="pingTimer.Enabled = False";
_pingtimer.setEnabled(__c.False);
 //BA.debugLineNum = 61;BA.debugLine="ReconnectTimer.Initialize(\"ReconnectTimer\",30000)";
_reconnecttimer.Initialize(ba,"ReconnectTimer",(long) (30000));
 //BA.debugLineNum = 62;BA.debugLine="pingTimer.Initialize(\"pingTimer\",10000)";
_pingtimer.Initialize(ba,"pingTimer",(long) (10000));
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public String  _pingtimer_tick() throws Exception{
b4a.example.main._message _msg = null;
byte[] _data = null;
String _base64 = "";
anywheresoftware.b4a.objects.collections.Map _m = null;
 //BA.debugLineNum = 259;BA.debugLine="Sub pingTimer_Tick()";
 //BA.debugLineNum = 260;BA.debugLine="Log(\"B4XMainPages pingTimer_Time==>\")";
__c.LogImpl("11179649","B4XMainPages pingTimer_Time==>",0);
 //BA.debugLineNum = 263;BA.debugLine="Dim msg As Message";
_msg = new b4a.example.main._message();
 //BA.debugLineNum = 264;BA.debugLine="msg.Initialize";
_msg.Initialize();
 //BA.debugLineNum = 265;BA.debugLine="msg.msg_id = 1";
_msg.msg_id /*String*/  = BA.NumberToString(1);
 //BA.debugLineNum = 266;BA.debugLine="msg.msg_text = \"測試 Message變數 是否能傳送??\"";
_msg.msg_text /*String*/  = "測試 Message變數 是否能傳送??";
 //BA.debugLineNum = 268;BA.debugLine="Dim Data() As Byte = mB4XSerializator.ConvertObje";
_data = _mb4xserializator.ConvertObjectToBytes((Object)(_msg));
 //BA.debugLineNum = 269;BA.debugLine="Dim Base64 As String = mStringUtils.EncodeBase64(";
_base64 = _mstringutils.EncodeBase64(_data);
 //BA.debugLineNum = 271;BA.debugLine="Log(\"Base64= \"&Base64)";
__c.LogImpl("11179660","Base64= "+_base64,0);
 //BA.debugLineNum = 274;BA.debugLine="Dim m As Map";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 275;BA.debugLine="m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 276;BA.debugLine="m.Put(\"message\",Base64)";
_m.Put((Object)("message"),(Object)(_base64));
 //BA.debugLineNum = 280;BA.debugLine="wsh.SendEventToServer(\"Server_Time\", m)";
_wsh._sendeventtoserver /*String*/ ("Server_Time",_m);
 //BA.debugLineNum = 283;BA.debugLine="End Sub";
return "";
}
public String  _reconnecttimer_tick() throws Exception{
 //BA.debugLineNum = 244;BA.debugLine="Sub ReconnectTimer_Tick()";
 //BA.debugLineNum = 245;BA.debugLine="Log(\"B4XMainPages ReconnectTimer_Timer==>\")";
__c.LogImpl("11114113","B4XMainPages ReconnectTimer_Timer==>",0);
 //BA.debugLineNum = 247;BA.debugLine="If wsh.ws.Connected = False Then";
if (_wsh._ws /*anywheresoftware.b4a.objects.WebSocketWrapper*/ .getConnected()==__c.False) { 
 //BA.debugLineNum = 248;BA.debugLine="ReconnectTimer.Enabled = False";
_reconnecttimer.setEnabled(__c.False);
 //BA.debugLineNum = 250;BA.debugLine="wsh.Connect(serverLink)";
_wsh._connect /*String*/ (_serverlink);
 //BA.debugLineNum = 251;BA.debugLine="ProgressDialogShow(\"Auto Connect~~~\"&serverLink)";
__c.ProgressDialogShow(ba,BA.ObjectToCharSequence("Auto Connect~~~"+_serverlink));
 };
 //BA.debugLineNum = 256;BA.debugLine="End Sub";
return "";
}
public String  _wsh_chkresult(anywheresoftware.b4a.objects.collections.List _params) throws Exception{
String _r = "";
int _i = 0;
anywheresoftware.b4a.objects.collections.Map _m = null;
 //BA.debugLineNum = 376;BA.debugLine="Sub wsh_CHKResult(Params As List)";
 //BA.debugLineNum = 377;BA.debugLine="Log(\"B4XMainPages wsh_CHKResult==>\")";
__c.LogImpl("135782657","B4XMainPages wsh_CHKResult==>",0);
 //BA.debugLineNum = 379;BA.debugLine="ProgressDialogHide";
__c.ProgressDialogHide();
 //BA.debugLineNum = 381;BA.debugLine="Dim r As String = \"\"";
_r = "";
 //BA.debugLineNum = 383;BA.debugLine="For i = 0 To Params.Size - 1";
{
final int step4 = 1;
final int limit4 = (int) (_params.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit4 ;_i = _i + step4 ) {
 //BA.debugLineNum = 385;BA.debugLine="Log($\"Params.get(${i})=> \"$ & Params.Get(i))";
__c.LogImpl("135782665",("Params.get("+__c.SmartStringFormatter("",(Object)(_i))+")=> ")+BA.ObjectToString(_params.Get(_i)),0);
 //BA.debugLineNum = 387;BA.debugLine="r = Params.Get(i)";
_r = BA.ObjectToString(_params.Get(_i));
 }
};
 //BA.debugLineNum = 391;BA.debugLine="If r = \"fail\" Then";
if ((_r).equals("fail")) { 
 //BA.debugLineNum = 393;BA.debugLine="Log(\"fail\")";
__c.LogImpl("135782673","fail",0);
 //BA.debugLineNum = 394;BA.debugLine="xui.MsgboxAsync(\"user/password wrong\",\"提示\")";
_xui.MsgboxAsync(ba,BA.ObjectToCharSequence("user/password wrong"),BA.ObjectToCharSequence("提示"));
 }else {
 //BA.debugLineNum = 399;BA.debugLine="Dim m As Map";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 400;BA.debugLine="m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 401;BA.debugLine="m.Put(\"device_id\", txtDevice_Id.text)";
_m.Put((Object)("device_id"),(Object)(_txtdevice_id.getText()));
 //BA.debugLineNum = 402;BA.debugLine="m.Put(\"user_id\", txtUser_Id.text)";
_m.Put((Object)("user_id"),(Object)(_txtuser_id._gettext /*String*/ ()));
 //BA.debugLineNum = 404;BA.debugLine="m.Put(\"app_version\", APP_VERSION)";
_m.Put((Object)("app_version"),(Object)(_app_version));
 //BA.debugLineNum = 405;BA.debugLine="m.Put(\"CheckBox1\",CheckBox1.Checked)	'VPS?!";
_m.Put((Object)("CheckBox1"),(Object)(_checkbox1.getChecked()));
 //BA.debugLineNum = 407;BA.debugLine="File.WriteMap(xui.DefaultFolder,\"config.txt\",m)";
__c.File.WriteMap(_xui.getDefaultFolder(),"config.txt",_m);
 //BA.debugLineNum = 410;BA.debugLine="B4XPages.ShowPageAndRemovePreviousPages(\"page1\")";
_b4xpages._showpageandremovepreviouspages /*String*/ (ba,"page1");
 //BA.debugLineNum = 411;BA.debugLine="Is_B1PageCreate = True";
_is_b1pagecreate = __c.True;
 //BA.debugLineNum = 412;BA.debugLine="Is_Page1 = True		'是否為頁面1";
_is_page1 = __c.True;
 //BA.debugLineNum = 414;BA.debugLine="Try";
try { //BA.debugLineNum = 416;BA.debugLine="CallSub2(page1, \"UpdateStatus\", wsh.ws.Connecte";
__c.CallSubNew2(ba,(Object)(_page1),"UpdateStatus",(Object)(_wsh._ws /*anywheresoftware.b4a.objects.WebSocketWrapper*/ .getConnected()));
 //BA.debugLineNum = 417;BA.debugLine="CallSub2(page1, \"UpdatePageTitle\", txtDevice_Id";
__c.CallSubNew2(ba,(Object)(_page1),"UpdatePageTitle",(Object)(_txtdevice_id.getText()));
 //BA.debugLineNum = 420;BA.debugLine="pingTimer.Enabled = True";
_pingtimer.setEnabled(__c.True);
 } 
       catch (Exception e27) {
			ba.setLastException(e27); //BA.debugLineNum = 425;BA.debugLine="Log(LastException)";
__c.LogImpl("135782705",BA.ObjectToString(__c.LastException(ba)),0);
 };
 };
 //BA.debugLineNum = 433;BA.debugLine="End Sub";
return "";
}
public String  _wsh_closed(String _reason) throws Exception{
 //BA.debugLineNum = 300;BA.debugLine="Sub wsh_Closed (Reason As String)";
 //BA.debugLineNum = 301;BA.debugLine="Log(\"B4XMainPages wsh_Closed==> \")";
__c.LogImpl("11310721","B4XMainPages wsh_Closed==> ",0);
 //BA.debugLineNum = 303;BA.debugLine="Log(\"中斷理由: \" & Reason)";
__c.LogImpl("11310723","中斷理由: "+_reason,0);
 //BA.debugLineNum = 304;BA.debugLine="ProgressDialogHide";
__c.ProgressDialogHide();
 //BA.debugLineNum = 306;BA.debugLine="Try";
try { //BA.debugLineNum = 307;BA.debugLine="If Is_B1PageCreate Then	'B1Page頁面需要先創建,才能更新畫面";
if (_is_b1pagecreate) { 
 //BA.debugLineNum = 308;BA.debugLine="CallSub2(page1, \"UpdateStatus\", wsh.ws.Connecte";
__c.CallSubNew2(ba,(Object)(_page1),"UpdateStatus",(Object)(_wsh._ws /*anywheresoftware.b4a.objects.WebSocketWrapper*/ .getConnected()));
 };
 //BA.debugLineNum = 313;BA.debugLine="If Is_Page1 = False Then '登陸模式下";
if (_is_page1==__c.False) { 
 //BA.debugLineNum = 315;BA.debugLine="xui.MsgboxAsync(\"connect fail?!!\",\"提示\")";
_xui.MsgboxAsync(ba,BA.ObjectToCharSequence("connect fail?!!"),BA.ObjectToCharSequence("提示"));
 }else {
 //BA.debugLineNum = 319;BA.debugLine="Log(\"將會啟動自動重連...\")";
__c.LogImpl("11310739","將會啟動自動重連...",0);
 //BA.debugLineNum = 321;BA.debugLine="pingTimer.Enabled = False";
_pingtimer.setEnabled(__c.False);
 //BA.debugLineNum = 322;BA.debugLine="If wsh.ws.Connected = False Then ReconnectTimer";
if (_wsh._ws /*anywheresoftware.b4a.objects.WebSocketWrapper*/ .getConnected()==__c.False) { 
_reconnecttimer.setEnabled(__c.True);};
 };
 } 
       catch (Exception e16) {
			ba.setLastException(e16); //BA.debugLineNum = 327;BA.debugLine="Log(LastException)";
__c.LogImpl("11310747",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 334;BA.debugLine="End Sub";
return "";
}
public String  _wsh_connected() throws Exception{
 //BA.debugLineNum = 288;BA.debugLine="Sub wsh_Connected";
 //BA.debugLineNum = 289;BA.debugLine="Log(\"B4XMainPages wsh_Connected==>\")";
__c.LogImpl("11245185","B4XMainPages wsh_Connected==>",0);
 //BA.debugLineNum = 292;BA.debugLine="Log(\"連線成功Connected= \"&wsh.ws.Connected)";
__c.LogImpl("11245188","連線成功Connected= "+BA.ObjectToString(_wsh._ws /*anywheresoftware.b4a.objects.WebSocketWrapper*/ .getConnected()),0);
 //BA.debugLineNum = 294;BA.debugLine="ReconnectTimer.Enabled = False";
_reconnecttimer.setEnabled(__c.False);
 //BA.debugLineNum = 298;BA.debugLine="End Sub";
return "";
}
public String  _wsh_newdeviceid(anywheresoftware.b4a.objects.collections.List _params) throws Exception{
int _i = 0;
 //BA.debugLineNum = 361;BA.debugLine="Sub wsh_NewDeviceId(Params As List)";
 //BA.debugLineNum = 362;BA.debugLine="Log(\"B4XMainPages wsh_NewDeviceId==>\")";
__c.LogImpl("11441793","B4XMainPages wsh_NewDeviceId==>",0);
 //BA.debugLineNum = 364;BA.debugLine="For i = 0 To Params.Size - 1";
{
final int step2 = 1;
final int limit2 = (int) (_params.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit2 ;_i = _i + step2 ) {
 //BA.debugLineNum = 366;BA.debugLine="Log($\"Params.get(${i})=> \"$ & Params.Get(i))";
__c.LogImpl("11441797",("Params.get("+__c.SmartStringFormatter("",(Object)(_i))+")=> ")+BA.ObjectToString(_params.Get(_i)),0);
 //BA.debugLineNum = 367;BA.debugLine="txtDevice_Id.text = Params.Get(i)";
_txtdevice_id.setText(BA.ObjectToCharSequence(_params.Get(_i)));
 }
};
 //BA.debugLineNum = 370;BA.debugLine="Log(\"Device_Id: \"&txtDevice_Id.text)";
__c.LogImpl("11441801","Device_Id: "+_txtdevice_id.getText(),0);
 //BA.debugLineNum = 373;BA.debugLine="End Sub";
return "";
}
public String  _wsh_newmessage(anywheresoftware.b4a.objects.collections.List _params) throws Exception{
anywheresoftware.b4a.objects.collections.List _ids = null;
int _i = 0;
anywheresoftware.b4a.objects.collections.Map _m = null;
String _s1 = "";
String _s2 = "";
b4a.example.nb6 _n = null;
anywheresoftware.b4a.objects.collections.Map _mm = null;
 //BA.debugLineNum = 436;BA.debugLine="Sub wsh_NewMessage(Params As List)";
 //BA.debugLineNum = 437;BA.debugLine="Log(\"B4XMainPages wsh_NewMessage==>\")";
__c.LogImpl("11572865","B4XMainPages wsh_NewMessage==>",0);
 //BA.debugLineNum = 439;BA.debugLine="Try";
try { //BA.debugLineNum = 440;BA.debugLine="Dim ids As List";
_ids = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 441;BA.debugLine="ids.Initialize";
_ids.Initialize();
 //BA.debugLineNum = 443;BA.debugLine="Log(\"=======訊息清單============\")";
__c.LogImpl("11572871","=======訊息清單============",0);
 //BA.debugLineNum = 445;BA.debugLine="For i = 0 To Params.Size - 1";
{
final int step6 = 1;
final int limit6 = (int) (_params.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit6 ;_i = _i + step6 ) {
 //BA.debugLineNum = 449;BA.debugLine="Log($\"Params.get(${i})=> \"$ & Params.Get(i))";
__c.LogImpl("11572877",("Params.get("+__c.SmartStringFormatter("",(Object)(_i))+")=> ")+BA.ObjectToString(_params.Get(_i)),0);
 //BA.debugLineNum = 452;BA.debugLine="Dim m As Map = Params.Get(i)";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_params.Get(_i)));
 //BA.debugLineNum = 454;BA.debugLine="Log(\"msg_id= \"&m.get(\"msg_id\"))";
__c.LogImpl("11572882","msg_id= "+BA.ObjectToString(_m.Get((Object)("msg_id"))),0);
 //BA.debugLineNum = 455;BA.debugLine="Log(\"msg_text= \"&m.get(\"msg_text\"))";
__c.LogImpl("11572883","msg_text= "+BA.ObjectToString(_m.Get((Object)("msg_text"))),0);
 //BA.debugLineNum = 456;BA.debugLine="Dim s1 As String = m.get(\"msg_id\")";
_s1 = BA.ObjectToString(_m.Get((Object)("msg_id")));
 //BA.debugLineNum = 457;BA.debugLine="Dim s2 As String = m.get(\"msg_text\")";
_s2 = BA.ObjectToString(_m.Get((Object)("msg_text")));
 //BA.debugLineNum = 458;BA.debugLine="Try";
try { //BA.debugLineNum = 459;BA.debugLine="CallSub3( page1,\"UpdateMessage\", s1, s2 )";
__c.CallSubNew3(ba,(Object)(_page1),"UpdateMessage",(Object)(_s1),(Object)(_s2));
 } 
       catch (Exception e16) {
			ba.setLastException(e16); //BA.debugLineNum = 461;BA.debugLine="Log(LastException)";
__c.LogImpl("11572889",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 479;BA.debugLine="Dim N As NB6";
_n = new b4a.example.nb6();
 //BA.debugLineNum = 481;BA.debugLine="N.Initialize(\"default\", Application.LabelName,\"";
_n._initialize /*b4a.example.nb6*/ (ba,"default",(Object)(__c.Application.getLabelName()),"DEFAULT");
 //BA.debugLineNum = 482;BA.debugLine="N.AutoCancel(True)";
_n._autocancel /*b4a.example.nb6*/ (__c.True);
 //BA.debugLineNum = 483;BA.debugLine="N.SmallIcon(LoadBitmap(File.DirAssets,\"smiley.p";
_n._smallicon /*b4a.example.nb6*/ (__c.LoadBitmap(__c.File.getDirAssets(),"smiley.png"));
 //BA.debugLineNum = 494;BA.debugLine="N.Build(\"Push\",s2,\"tag1\", Main ).Notify(1)";
_n._build /*anywheresoftware.b4a.objects.NotificationWrapper*/ ((Object)("Push"),(Object)(_s2),"tag1",(Object)(_main.getObject())).Notify((int) (1));
 //BA.debugLineNum = 502;BA.debugLine="Dim mm As Map";
_mm = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 503;BA.debugLine="mm.Initialize";
_mm.Initialize();
 //BA.debugLineNum = 505;BA.debugLine="mm.Put(\"device_id\", txtDevice_Id.text)";
_mm.Put((Object)("device_id"),(Object)(_txtdevice_id.getText()));
 //BA.debugLineNum = 506;BA.debugLine="mm.Put(\"user_id\", txtUser_Id.text)";
_mm.Put((Object)("user_id"),(Object)(_txtuser_id._gettext /*String*/ ()));
 //BA.debugLineNum = 507;BA.debugLine="mm.Put(\"msg_id\", s1)";
_mm.Put((Object)("msg_id"),(Object)(_s1));
 //BA.debugLineNum = 509;BA.debugLine="wsh.SendEventToServer(\"Client_DeviceMessageDeli";
_wsh._sendeventtoserver /*String*/ ("Client_DeviceMessageDelivered",_mm);
 }
};
 //BA.debugLineNum = 514;BA.debugLine="Log(\"=======訊息清單END============\")";
__c.LogImpl("11572942","=======訊息清單END============",0);
 } 
       catch (Exception e32) {
			ba.setLastException(e32); //BA.debugLineNum = 521;BA.debugLine="Log(LastException)";
__c.LogImpl("11572949",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 536;BA.debugLine="End Sub";
return "";
}
public String  _wsh_serverready(anywheresoftware.b4a.objects.collections.List _params) throws Exception{
anywheresoftware.b4a.objects.collections.Map _m = null;
 //BA.debugLineNum = 338;BA.debugLine="Sub wsh_ServerReady(Params As List)";
 //BA.debugLineNum = 339;BA.debugLine="Log(\"B4XMainPages wsh_ServerReady==>\")";
__c.LogImpl("11376257","B4XMainPages wsh_ServerReady==>",0);
 //BA.debugLineNum = 341;BA.debugLine="Log(\"ServerReady伺服器已經準備好了...\")";
__c.LogImpl("11376259","ServerReady伺服器已經準備好了...",0);
 //BA.debugLineNum = 346;BA.debugLine="Dim m As Map";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 347;BA.debugLine="m.Initialize";
_m.Initialize();
 //BA.debugLineNum = 348;BA.debugLine="m.Put(\"device_id\", txtDevice_Id.text)";
_m.Put((Object)("device_id"),(Object)(_txtdevice_id.getText()));
 //BA.debugLineNum = 349;BA.debugLine="m.Put(\"user_id\", txtUser_Id.text)";
_m.Put((Object)("user_id"),(Object)(_txtuser_id._gettext /*String*/ ()));
 //BA.debugLineNum = 351;BA.debugLine="m.Put(\"app_version\", APP_VERSION)";
_m.Put((Object)("app_version"),(Object)(_app_version));
 //BA.debugLineNum = 353;BA.debugLine="wsh.SendEventToServer(\"Server_CHK\", m)";
_wsh._sendeventtoserver /*String*/ ("Server_CHK",_m);
 //BA.debugLineNum = 358;BA.debugLine="End Sub";
return "";
}
public String  _wsh_servertime(anywheresoftware.b4a.objects.collections.List _params) throws Exception{
int _i = 0;
 //BA.debugLineNum = 539;BA.debugLine="Sub wsh_ServerTime(Params As List)";
 //BA.debugLineNum = 541;BA.debugLine="For i = 0 To Params.Size - 1";
{
final int step1 = 1;
final int limit1 = (int) (_params.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit1 ;_i = _i + step1 ) {
 //BA.debugLineNum = 543;BA.debugLine="Log($\"Params.get(${i})=> \"$ & Params.Get(i))";
__c.LogImpl("11638404",("Params.get("+__c.SmartStringFormatter("",(Object)(_i))+")=> ")+BA.ObjectToString(_params.Get(_i)),0);
 //BA.debugLineNum = 545;BA.debugLine="If Is_B1PageCreate Then";
if (_is_b1pagecreate) { 
 //BA.debugLineNum = 546;BA.debugLine="CallSub2( page1,\"UpdateTime\", Params.Get(i))";
__c.CallSubNew2(ba,(Object)(_page1),"UpdateTime",_params.Get(_i));
 };
 }
};
 //BA.debugLineNum = 552;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
