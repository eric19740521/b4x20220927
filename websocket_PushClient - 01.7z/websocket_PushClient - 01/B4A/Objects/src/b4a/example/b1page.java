package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class b1page extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.b1page");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.b1page.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblws_status = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblws_time = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _edittext1 = null;
public b4a.example3.customlistview _customlistview1 = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.main _main = null;
public b4a.example.starter _starter = null;
public b4a.example.b4xpages _b4xpages = null;
public b4a.example.b4xcollections _b4xcollections = null;
public b4a.example.xuiviewsutils _xuiviewsutils = null;
public String  _activityresume() throws Exception{
 //BA.debugLineNum = 177;BA.debugLine="Public Sub ActivityResume";
 //BA.debugLineNum = 178;BA.debugLine="Log(\"B4XMainPage ActivityResume==>\")";
__c.LogImpl("11900545","B4XMainPage ActivityResume==>",0);
 //BA.debugLineNum = 179;BA.debugLine="B4XPages.ShowPage(\"MainPage\")";
_b4xpages._showpage /*String*/ (ba,"MainPage");
 //BA.debugLineNum = 193;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 28;BA.debugLine="Log(\"B1Page B4XPage_Created==>\")";
__c.LogImpl("11835009","B1Page B4XPage_Created==>",0);
 //BA.debugLineNum = 30;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 33;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 34;BA.debugLine="Root.LoadLayout(\"B1Page\")";
_root.LoadLayout("B1Page",ba);
 //BA.debugLineNum = 36;BA.debugLine="B4XPages.SetTitle(Me, \"訊息接收\")";
_b4xpages._settitle /*String*/ (ba,this,(Object)("訊息接收"));
 //BA.debugLineNum = 38;BA.debugLine="EditText1.Text = \"\"";
_edittext1.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 41;BA.debugLine="lblws_time.Text = \"\"";
_lblws_time.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 42;BA.debugLine="lblws_time.Color = xui.Color_Blue";
_lblws_time.setColor(_xui.Color_Blue);
 //BA.debugLineNum = 43;BA.debugLine="lblws_time.TextColor = xui.Color_White";
_lblws_time.setTextColor(_xui.Color_White);
 //BA.debugLineNum = 45;BA.debugLine="lblws_status.Text = \"斷線中\"";
_lblws_status.setText(BA.ObjectToCharSequence("斷線中"));
 //BA.debugLineNum = 46;BA.debugLine="lblws_status.Color = xui.Color_Red";
_lblws_status.setColor(_xui.Color_Red);
 //BA.debugLineNum = 47;BA.debugLine="lblws_status.TextColor = xui.Color_White";
_lblws_status.setTextColor(_xui.Color_White);
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private Root As B4XView 'ignore";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 3;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 7;BA.debugLine="Private lblws_status As B4XView";
_lblws_status = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 8;BA.debugLine="Private lblws_time As B4XView";
_lblws_time = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 9;BA.debugLine="Private EditText1 As B4XView";
_edittext1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private CustomListView1 As CustomListView";
_customlistview1 = new b4a.example3.customlistview();
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 15;BA.debugLine="Public Sub Initialize As Object";
 //BA.debugLineNum = 16;BA.debugLine="Log(\"B1Page Initialize==>\")";
__c.LogImpl("11769473","B1Page Initialize==>",0);
 //BA.debugLineNum = 23;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return null;
}
public String  _updatemessage(String _s1,String _s2) throws Exception{
String _s = "";
 //BA.debugLineNum = 241;BA.debugLine="public Sub UpdateMessage(s1 As String,s2 As String";
 //BA.debugLineNum = 245;BA.debugLine="Dim s As String = \"Message Id: \" & s1 & \", \" & s2";
_s = "Message Id: "+_s1+", "+_s2;
 //BA.debugLineNum = 249;BA.debugLine="CustomListView1.AddTextItem(s,s)";
_customlistview1._addtextitem((Object)(_s),(Object)(_s));
 //BA.debugLineNum = 253;BA.debugLine="CustomListView1.ScrollToItem(CustomListView1.Size";
_customlistview1._scrolltoitem((int) (_customlistview1._getsize()-1));
 //BA.debugLineNum = 261;BA.debugLine="End Sub";
return "";
}
public String  _updatepagetitle(String _s1) throws Exception{
 //BA.debugLineNum = 263;BA.debugLine="public Sub UpdatePageTitle(s1 As String)";
 //BA.debugLineNum = 265;BA.debugLine="B4XPages.SetTitle(Me, $\"Device_Id: ${s1}\"$)";
_b4xpages._settitle /*String*/ (ba,this,(Object)(("Device_Id: "+__c.SmartStringFormatter("",(Object)(_s1))+"")));
 //BA.debugLineNum = 266;BA.debugLine="End Sub";
return "";
}
public String  _updatestatus(boolean _b) throws Exception{
String _d1 = "";
long _now = 0L;
 //BA.debugLineNum = 214;BA.debugLine="public Sub UpdateStatus(b As Boolean)";
 //BA.debugLineNum = 217;BA.debugLine="Dim d1 As String";
_d1 = "";
 //BA.debugLineNum = 220;BA.debugLine="DateTime.TimeFormat = \"HH:mm:ss\"		'\"HH:mm:ss\"";
__c.DateTime.setTimeFormat("HH:mm:ss");
 //BA.debugLineNum = 221;BA.debugLine="DateTime.DateFormat = \"yyyy-MM-dd\"";
__c.DateTime.setDateFormat("yyyy-MM-dd");
 //BA.debugLineNum = 223;BA.debugLine="Dim now As Long = DateTime.Now		'回傳Long型態";
_now = __c.DateTime.getNow();
 //BA.debugLineNum = 225;BA.debugLine="d1 = DateTime.Date(now) & \" \" & DateTime.Time(now";
_d1 = __c.DateTime.Date(_now)+" "+__c.DateTime.Time(_now);
 //BA.debugLineNum = 228;BA.debugLine="lblws_status.SetTextAlignment(\"CENTER\",\"CENTER\")";
_lblws_status.SetTextAlignment("CENTER","CENTER");
 //BA.debugLineNum = 229;BA.debugLine="If b = True Then";
if (_b==__c.True) { 
 //BA.debugLineNum = 230;BA.debugLine="lblws_status.Text = \"已連線:\"&d1";
_lblws_status.setText(BA.ObjectToCharSequence("已連線:"+_d1));
 //BA.debugLineNum = 231;BA.debugLine="lblws_status.Color = xui.Color_Green";
_lblws_status.setColor(_xui.Color_Green);
 //BA.debugLineNum = 232;BA.debugLine="lblws_status.TextColor = xui.Color_red";
_lblws_status.setTextColor(_xui.Color_Red);
 }else {
 //BA.debugLineNum = 234;BA.debugLine="lblws_status.Text = \"斷線中\"&d1";
_lblws_status.setText(BA.ObjectToCharSequence("斷線中"+_d1));
 //BA.debugLineNum = 235;BA.debugLine="lblws_status.Color = xui.Color_Red";
_lblws_status.setColor(_xui.Color_Red);
 //BA.debugLineNum = 236;BA.debugLine="lblws_status.TextColor = xui.Color_White";
_lblws_status.setTextColor(_xui.Color_White);
 };
 //BA.debugLineNum = 239;BA.debugLine="End Sub";
return "";
}
public String  _updatetime(String _s1) throws Exception{
 //BA.debugLineNum = 269;BA.debugLine="public Sub UpdateTime(s1 As String)";
 //BA.debugLineNum = 272;BA.debugLine="lblws_time.SetTextAlignment(\"CENTER\",\"CENTER\")";
_lblws_time.SetTextAlignment("CENTER","CENTER");
 //BA.debugLineNum = 273;BA.debugLine="lblws_time.Text = s1";
_lblws_time.setText(BA.ObjectToCharSequence(_s1));
 //BA.debugLineNum = 274;BA.debugLine="lblws_time.Color = xui.Color_Blue";
_lblws_time.setColor(_xui.Color_Blue);
 //BA.debugLineNum = 275;BA.debugLine="lblws_time.TextColor = xui.Color_White";
_lblws_time.setTextColor(_xui.Color_White);
 //BA.debugLineNum = 277;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
if (BA.fastSubCompare(sub, "UPDATEMESSAGE"))
	return _updatemessage((String) args[0], (String) args[1]);
if (BA.fastSubCompare(sub, "UPDATEPAGETITLE"))
	return _updatepagetitle((String) args[0]);
if (BA.fastSubCompare(sub, "UPDATESTATUS"))
	return _updatestatus((Boolean) args[0]);
if (BA.fastSubCompare(sub, "UPDATETIME"))
	return _updatetime((String) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
